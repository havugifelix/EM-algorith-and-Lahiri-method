clear all
close all
%Domain values
xmin= 1;
xmax=15 ;
% Domain set
x = 0:15;
lamda=2
y = poisspdf(x,lamda);
%Getting pdf of poisson distribtion

plot(x,y)
m=max(y);
i=1
while (i<1000)
    t=rand;
    x_sample=(xmax-xmin)*t +xmin; 
    u= m.*rand;
    pdxi=poisspdf(x,lamda);
    if u <= pdxi;
        sample(i)=x_sample;
        i=i+1
        
    
    end

end 
disp(sample)
subplot(2,1,1)
plot(x,y)
title('Subplot 1: poisson Pdf vs X')
subplot(2,1,2)S
hist(samples)
title('Subplot 1: Generated samples from poisson distribution')

